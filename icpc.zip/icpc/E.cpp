#include <iostream>

int main() {
    int a;
    int b;
    int k;
    int result = 0;
    std::cin >> a;
    std::cin >> b;
    std::cin >> k;
    for (int i = 1; i <= k; i++) {
        result = (a*i)+b;
        std::cout << result << " ";
    }
    
    return 0;
}