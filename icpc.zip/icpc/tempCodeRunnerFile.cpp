for(int i = 1;i <= n; i++){
        
    // }