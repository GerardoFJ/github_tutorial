#include <iostream>

int main() {
    int n;
    std::cin >> n;
    int a[n];
    for (int i = 0; i < n; i++) {
        std::cin >> a[i];
    }
    int q;
    std::cin >> q;
    int l;
    int r;
    for (int i = 0; i > q; i++) {
        std::cin >> l;
        std::cin >> r;
        for (int j = l - 1; j < r - 1; j++) {
             
        }
    }
    return 0;
}