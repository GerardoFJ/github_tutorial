#include <iostream>
#include <vector>


int get_number(int number){
    int get_low_number = number % 2;
    std::vector<int> as;
    std::vector<int> bs;
    std::vector<int> cs;
    
    if(get_low_number == 0){
        int base_number = number / 2;
        // std::cout<<base_number<<std::endl;
        for(int i = base_number-1; i > 0;i--){
            int new_middle = number-i;
            int iterations = 0;
            if(new_middle %2 !=0){
                iterations = (new_middle -1) /2;
            }
            else {
                iterations = new_middle/2;
            }
            //int iterations = new_middl
            for(int z = 1; z <= iterations;z++){
                int a = z;
                int b = new_middle-a;

                triangles[0] = i;
                triangles[1] = a;
                triangles[2] = b;
            }

        }

    }
    return 0;
}

int main () {
    int n;
    std::cin >> n;
    get_number(6);
    // for(int i = 1;i <= n; i++){
        
    // }
    return 0;
}