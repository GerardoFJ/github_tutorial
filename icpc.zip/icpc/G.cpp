#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>

int main () {
    int n;
    std::cin>>n;
    std::priority_queue<int,std::vector<int>,std::greater<int>> q;
    int input;
    for (int i = 0; i < n; i++) {
        std::cin>>input;
        q.push(input);
    }
    int count = 0;
    int num = 0;
    while (!q.empty()) {
        //std::cout<<q.top()<<" ";
        int current = q.top() - num;
        //std::cout<<current<<std::endl;
        if (current != 0) {
            count++;
        } else {
            q.pop();
        }
        num += current;
    }
    //std::cout<<"count "<<count<<std::endl;
    if (count % 2 == 0) {
        std::cout<<"Bobius";
    } else {
        std::cout<<"Alicius";
    }
}