#include <iostream>
#include <vector>

int n, k;
int tablero[26][26];
//int atacados[25][25];
std::vector<int[2]> inputs;
std::vector<int[2]> caballos;

int checking(std::vector<int[2]> c) {

    return 0;
}

bool estaAtacando(int x, int y) {
    int xs[] = {2, 2, -2, -2, 1, -1, 1, -1};
    int ys[] = {1, -1, 1, -1, 2, 2, -2, -2};
    for (int j = 0; j < 8; j++) {
        for (int i = 0; i < caballos.size(); ++i) {
            if (caballos[i][0] == xs[j] && caballos[i][1] == ys[j]) {
                return true;
            }
        }
    }
    return false;
}

int main() {
    std::cin>>n>>k;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            tablero[i][j] = 0;
        }
    }
    int x, y;
    for (int i = 0; i < k; i++) {
        std::cin>>x>>y;
        tablero[x][y] += 1;
        inputs.push_back({x,y});
    }
    /*for (int i = 0; i < k; i++) {
        if (estaAtacando(inputs[i][0],inputs[i][1])) {
            caballos.push_back(inputs[i]);
        }
    }*/
    std::cout<<checking();
    return 0;
}