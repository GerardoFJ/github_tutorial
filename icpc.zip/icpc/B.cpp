#include <iostream>
#include <queue>
#include <stack>

int main() {
    int t;
    std::cin>>t;
    int n[t];
    int ans[t] = {0};
    // for (int i = 0; i < t; i++) {
        for (int j = 0; j < t; j++) {
            std::cin>>n[j];
        }
        int max = 0;
        for (int j = 0; j < t; j++) {
            if (max < n[j]) {
                max = n[j];
            }
        }
        // long long int currentMax = __LONG_LONG_MAX__;
        // for (int j = 0; j < t; j++) {

        // }
        std::queue<int> news;
        std::queue<int> mature;
        std::queue<int> dies;
        std::queue<int> adults;
        long long int bacteria = 1;
        news.push(2);
        for (int j = 1; j <= max; j++) {
            while (!news.empty() && news.front() == j) {
                mature.push(j+4);
                news.pop();
                // std::cout<<"new "<<j<<std::endl;
            }
            while (!mature.empty() && mature.front() == j) {
                adults.push(j+4);
                news.push(j+2);
                news.push(j+2);
                news.push(j+2);
                dies.push(j+20);
                dies.push(j+20);
                dies.push(j+20);
                bacteria += 3;
                mature.pop();
                // std::cout<<"mature "<<j<<std::endl;
            }
            while (!adults.empty() && adults.front() == j) {
                adults.push(j+4);
                news.push(j+2);
                news.push(j+2);
                news.push(j+2);
                bacteria += 3;
                adults.pop();
            }
            while (!dies.empty() && dies.front() == j) {
                bacteria--;
                dies.pop();
                adults.pop();
                // std::cout<<"dies "<<j<<std::endl;
            }
            for (int k = 0; k < t; k++) {
                if (n[k] == j) {
                    ans[k] = bacteria;
                }
            }
        }
        long long int mod = (1e9+7);
        for (int i = 0; i < t; i++) {
            std::cout<<ans[i]%mod<<std::endl;
        }
    // }
    return 0;
}