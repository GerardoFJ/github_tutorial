#include <iostream>

int main () {
    int a[3], b[3];
    std::cin >> a[0] >> a[1] >> a[2] >> b[0] >> b[1] >> b[2];
    int max = 0;
    for (int i = 0; i < 3; i++) {
        int m = 1;
        for (int j = 0; j < 3; j++) {
            m *= a[j] / b[(i + j) % 3];
        }
        if (m > max) {
            max = m;
        }
    }
    std::swap(a[1], a[2]);
    for (int i = 0; i < 3; i++) {
        int m = 1;
        for (int j = 0; j < 3; j++) {
            m *= a[j] / b[(i + j) % 3];
        }
        if (m > max) {
            max = m;
        }
    }
    std::cout << max;
    return 0;
}
/*
6 5 4
3 2 1
*/